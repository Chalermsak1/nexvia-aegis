from pathlib import Path
import hashlib,json,sys,zipfile
out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
with zipfile.ZipFile(sys.argv[1]) as z:
 for logical,item in json.loads(z.read('manifest.json')).items():
  p=Path(logical)
  if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe logical path')
  b=z.read(item['member'])
  if len(b)!=item['size_bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:raise ValueError('integrity mismatch')
  target=out/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
