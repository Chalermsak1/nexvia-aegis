import hashlib,json,sys,zipfile
from pathlib import Path
archive=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as z:
 for logical,record in json.loads(z.read('manifest.json'))['files'].items():
  rel=Path(logical)
  if rel.is_absolute() or '..' in rel.parts:raise ValueError('unsafe logical path')
  raw=z.read(record['member'])
  if len(raw)!=record['size_bytes'] or hashlib.sha256(raw).hexdigest()!=record['sha256']:raise ValueError('content mismatch')
  target=out/rel;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(raw)
print('Restored verified fixture bytes')
