from pathlib import Path
import json,hashlib
import aegis
from scripts.research import physical_reference_study as reference,brake_probe_study as probe
from scripts.research.development_ledger import DevelopmentLedger,LedgerError,LedgerWriteError
root=Path.cwd().resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results={}
for name,module,original in [('reference',reference,'/private/tmp/nexvia-reference-actual-v1-20261116.jsonl'),('probe',probe,'/private/tmp/nexvia-probe-actual-v1-20261116.jsonl')]:
 assert Path(module.__file__).resolve().is_relative_to(root) and Path(aegis.__file__).resolve().is_relative_to(root)
 header=json.loads((root/(name+'_header.json')).read_text());meta=header['assignments'][0]['metadata'];assert module.hashes()==meta['sources']
 versions={'python':module.platform.python_version(),'numpy':module.np.__version__,'mujoco':module.mujoco.__version__};assert versions==meta['versions']
 out=root/(name+'_reproduction.jsonl')
 with DevelopmentLedger.create(out,study=module.STUDY,assignments=header['assignments'],record_events=True) as w:
  for a in header['assignments']:
   w.start(a['id'])
   try:
    execute=module.run_episode if name=='reference' else module.execute
    result=execute(a,lambda e:w.event(a['id'],details=e));assert module.hashes()==meta['sources']
    w.complete(a['id'],status='COMPLETED',details={'summary':result,'sources_after':module.hashes()})
   except (LedgerError,LedgerWriteError):raise
   except Exception as exc:w.complete(a['id'],status='ERROR',details={'error_type':type(exc).__name__,'error':str(exc)});raise
  w.finalize()
 summary=module.audit(out);(root/(name+'_summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
 assert sha(out)==sha(Path(original))
 results[name]={'byte_identical':True,'sha256':sha(out),'counts':summary['counts'],'source_sha256':module.hashes(),'runtime_versions':versions,'module_origin':str(Path(module.__file__).resolve())}
receipt={'classification':'SAME_RUNTIME_SEPARATE_SOURCE_PATH_REPRODUCTION','studies':results,'driver_sha256':sha(Path(__file__)),
 'extra_namespace_sha256':{p:sha(root/p) for p in ['src/aegis/__init__.py','src/aegis/env/__init__.py']},
 'limitation':'Same existing interpreter/native runtime; no independent authentication, reviewer approval or scientific replication.',
 'parent_identity':'Copied from original executed headers; not a new checkout or release commit.','gate_b':'GATE_B_NOT_AUTHORIZED'}
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:{'byte_identical':v['byte_identical'],'sha256':v['sha256'],'counts':v['counts']} for k,v in results.items()}))
