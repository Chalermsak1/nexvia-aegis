from pathlib import Path
import hashlib,json,sys
import aegis
from scripts.research import dual_source_fallback_study as study
from scripts.research.development_ledger import DevelopmentLedger
root=Path.cwd().resolve()
assert Path(study.__file__).resolve().is_relative_to(root)
assert Path(aegis.__file__).resolve().is_relative_to(root)
header=json.loads((root/'header.json').read_text())
assignments=header['assignments']; sources=assignments[0]['metadata']['sources']
assert study.hashes()==sources
assert [{k:v for k,v in a.items() if k!='metadata'} for a in assignments]==study.plan()
path=root/'reproduction.jsonl'
with DevelopmentLedger.create(path,study=study.STUDY,assignments=assignments,record_events=True) as ledger:
    for a in assignments:
        ledger.start(a['id'])
        result=study.run_episode(a,lambda event:ledger.event(a['id'],details=event))
        assert study.hashes()==sources
        ledger.complete(a['id'],status='COMPLETED',details={'summary':result,'sources_after':study.hashes()})
    ledger.finalize()
summary=study.audit(path)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
original=Path('/private/tmp/nexvia-dual-actual-v1-20261116.jsonl')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(path)==sha(original)
receipt={'classification':'SAME_RUNTIME_SEPARATE_SOURCE_PATH_REPRODUCTION',
         'byte_identical_ledger':True,'ledger_sha256':sha(path),'sources':study.hashes(),
         'extra_namespace_source_sha256':{rel:sha(root/rel) for rel in ['src/aegis/__init__.py','src/aegis/env/__init__.py']},
         'driver_sha256':sha(Path(__file__)),
         'parent_identity':'Copied from actual executed header; not a new checkout or release commit.',
         'runtime_limitation':'Same existing interpreter and native dependencies, no independent provenance authentication or human review.',
         'module_origins':{'aegis':str(Path(aegis.__file__).resolve()),'study':str(Path(study.__file__).resolve())},
         'counts':summary['counts'],'gate_b':'GATE_B_NOT_AUTHORIZED'}
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'byte_identical_ledger':True,'sha256':sha(path),'counts':summary['counts']}))
