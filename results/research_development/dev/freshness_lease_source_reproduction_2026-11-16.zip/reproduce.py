from pathlib import Path
import json,hashlib
import aegis
from scripts.research import freshness_lease_study as study
from scripts.research.development_ledger import DevelopmentLedger
root=Path.cwd().resolve();header=json.loads((root/'header.json').read_text());sources=header['assignments'][0]['metadata']['sources']
assert Path(study.__file__).resolve().is_relative_to(root) and Path(aegis.__file__).resolve().is_relative_to(root)
assert study.hashes()==sources
versions={'python':study.platform.python_version(),'numpy':study.np.__version__,'mujoco':study.mujoco.__version__}
assert versions==header['assignments'][0]['metadata']['versions']
path=root/'reproduction.jsonl'
with DevelopmentLedger.create(path,study=study.STUDY,assignments=header['assignments'],record_events=True) as w:
 for a in header['assignments']:
  w.start(a['id'])
  try:
   result=study.run_episode(a,lambda e:w.event(a['id'],details=e))
   assert study.hashes()==sources
   w.complete(a['id'],status='COMPLETED',details={'summary':result,'sources_after':study.hashes()})
  except Exception as exc:
   # Underlying writer can remain poisoned; no retry or overwrite.
   from scripts.research.development_ledger import LedgerError,LedgerWriteError
   if isinstance(exc,(LedgerError,LedgerWriteError)):raise
   w.complete(a['id'],status='ERROR',details={'error_type':type(exc).__name__,'error':str(exc)});raise
 w.finalize()
summary=study.audit(path);(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('/private/tmp/nexvia-assurance-actual-v1-20261116.jsonl');assert sha(original)==sha(path)
receipt={'classification':'SAME_RUNTIME_SEPARATE_SOURCE_PATH_REPRODUCTION','byte_identical_ledger':True,
 'sha256':sha(path),'source_sha256':study.hashes(),'runtime_versions':versions,'driver_sha256':sha(Path(__file__)),
 'extra_namespace_sha256':{p:sha(root/p) for p in ['src/aegis/__init__.py','src/aegis/env/__init__.py']},
 'counts':summary['counts'],'parent_identity':'Copied from original execution header, not a new checkout/release commit.',
 'limitation':'Same existing interpreter/native runtime, not independent authentication or scientific replication.',
 'module_origins':{'study':str(Path(study.__file__).resolve()),'aegis':str(Path(aegis.__file__).resolve())},'gate_b':'GATE_B_NOT_AUTHORIZED'}
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'byte_identical':True,'sha256':sha(path),'counts':summary['counts']}))
